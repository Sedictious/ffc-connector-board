{
  "board": {
    "active_layer": 44,
    "active_layer_preset": "",
    "auto_track_width": false,
    "hidden_nets": [],
    "high_contrast_mode": 0,
    "net_color_mode": 1,
    "opacity": {
      "pads": 1.0,
      "tracks": 1.0,
      "vias": 1.0,
      "zones": 0.6
    },
    "ratsnest_display_mode": 0,
    "selection_filter": {
      "dimensions": true,
      "footprints": true,
      "graphics": true,
      "keepouts": true,
      "lockedItems": true,
      "otherItems": true,
      "pads": true,
      "text": true,
      "tracks": true,
      "vias": true,
      "zones": true
    },
    "visible_items": [
      0,
      1,
      2,
      3,
      4,
      5,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      16,
      17,
      18,
      19,
      20,
      21,
      22,
      23,
      24,
      25,
      26,
      27,
      28,
      29,
      30,
      32,
      33,
      34,
      35,
      36
    ],
    "visible_layers": "7ffffff_80000001",
    "zone_display_mode": 0
  },
  "meta": {
    "filename": "ffc-connector-board.kicad_prl",
    "version": 3
  },
  "project": {
    "files": []
  }
}
